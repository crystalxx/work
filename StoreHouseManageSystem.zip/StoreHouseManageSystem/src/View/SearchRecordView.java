package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.border.TitledBorder;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.UIManager;

import java.awt.Color;
import java.util.Vector;

import javax.swing.JTextField;










import Dao.SearchRecordDao;
import Model.EntryRecord;
import Model.Goods;
import Model.Record;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class SearchRecordView extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JComboBox comboBox;
	private JTable table_1;
	private JTable table_2;
	private JComboBox comboBox_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchRecordView frame = new SearchRecordView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchRecordView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 603, 556);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 10, 567, 470);
		contentPane.add(tabbedPane);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("��ⵥ", null, panel_1, null);
		panel_1.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(10, 71, 542, 361);
		panel_1.add(panel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 35, 522, 317);
		panel.add(scrollPane);
		
		table_1 = new JTable();
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u7F16\u53F7", "\u4ED3\u5E93", "\u8D27\u7269\u7F16\u53F7", "\u6570\u91CF", "\u65F6\u95F4"
			}
		));
		scrollPane.setViewportView(table_1);
		
		JLabel label = new JLabel("\u5165\u5E93\u5355");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(234, 10, 54, 15);
		panel.add(label);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(null, "\u67E5\u8BE2\u6761\u4EF6", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_4.setBounds(10, 10, 542, 51);
		panel_1.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8BF7\u9009\u62E9\u5355\u53F7:");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		lblNewLabel.setBounds(46, 26, 77, 15);
		panel_4.add(lblNewLabel);
		
		comboBox = new JComboBox();
		comboBox.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		comboBox.setBounds(155, 23, 121, 21);
		panel_4.add(comboBox);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchEntryRecord();
			}
		});
		btnNewButton.setBounds(354, 22, 93, 23);
		panel_4.add(btnNewButton);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		tabbedPane.addTab("���ⵥ", null, panel_2, null);
		
		JPanel panel_5 = new JPanel();
		panel_5.setLayout(null);
		panel_5.setBorder(new TitledBorder(null, "\u67E5\u8BE2\u6761\u4EF6", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_5.setBounds(10, 10, 542, 51);
		panel_2.add(panel_5);
		
		JLabel label_7 = new JLabel("\u8BF7\u9009\u62E9\u5355\u53F7:");
		label_7.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_7.setBounds(46, 26, 77, 15);
		panel_5.add(label_7);
		
		 comboBox_1 = new JComboBox();
		 comboBox_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		comboBox_1.setBounds(155, 23, 121, 21);
		panel_5.add(comboBox_1);
		
		JButton btnNewButton_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchOutRecord();
			}
		});
		btnNewButton_1.setBounds(345, 22, 93, 23);
		panel_5.add(btnNewButton_1);
		
		JPanel panel_6 = new JPanel();
		panel_6.setLayout(null);
		panel_6.setBounds(10, 71, 542, 360);
		panel_2.add(panel_6);
		
		JLabel label_8 = new JLabel("\u51FA\u5E93\u5355");
		label_8.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_8.setBounds(234, 10, 54, 15);
		panel_6.add(label_8);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 33, 522, 317);
		panel_6.add(scrollPane_1);
		
		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u7F16\u53F7", "\u4ED3\u5E93", "\u8D27\u7269\u7F16\u53F7", "\u6570\u91CF", "\u65F6\u95F4"
			}
		));
		scrollPane_1.setViewportView(table_2);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("�����ѯ", null, panel_3, null);
		panel_3.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 10, 542, 416);
		panel_3.add(scrollPane_2);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u8D27\u7269\u7F16\u53F7", "\u540D\u79F0", "\u6570\u91CF", "\u5355\u4EF7", "\u751F\u4EA7\u5546"
			}
		));
		scrollPane_2.setViewportView(table);
		
		JButton button_1 = new JButton("\u5173\u95ED");
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				concleActionPerformed();
			}
		});
		button_1.setBounds(249, 490, 93, 23);
		contentPane.add(button_1);
		fillcomboBox();
		fillcomboBox1();
		fillTable();
	}
	private void fillcomboBox()
	{
		SearchRecordDao dao = new SearchRecordDao();
		Vector<String> flag=null;
		try {
			flag = dao.findFlagEntryRecord();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!flag.isEmpty())
		{
			for(int i=0;i<flag.size();i++)
			{
				comboBox.addItem(flag.get(i));
			}
		}
	}
	private void fillcomboBox1()
	{
		SearchRecordDao dao = new SearchRecordDao();
		Vector<String> flag=null;
		try {
			flag = dao.findFlagOutRecord();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!flag.isEmpty())
		{
			for(int i=0;i<flag.size();i++)
			{
				comboBox_1.addItem(flag.get(i));
			}
		}
	}
	private void searchEntryRecord()
	{
		String info = comboBox.getSelectedItem().toString();
		SearchRecordDao dao = new SearchRecordDao();
		Vector<Record> v = null;
		try {
			v = dao.findEntryRecord(info);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DefaultTableModel dtm = (DefaultTableModel) table_1.getModel();
		dtm.setRowCount(0);
		
		for(int i= 0;i<v.size();i++)
		{
			Vector<String> s = new Vector<String>();
			s.add(v.get(i).getFlag());
			s.add(v.get(i).getcAddress());
			s.add(v.get(i).getGoods().getId());
			s.add(v.get(i).getNum());
			s.add(v.get(i).getDate());
			dtm.addRow(s);
		}
	}
	private void searchOutRecord()
	{
		String info = comboBox_1.getSelectedItem().toString();
		SearchRecordDao dao = new SearchRecordDao();
		Vector<Record> v = null;
		try {
			v = dao.findOutRecord(info);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DefaultTableModel dtm = (DefaultTableModel) table_2.getModel();
		dtm.setRowCount(0);
		
		for(int i= 0;i<v.size();i++)
		{
			Vector<String> s = new Vector<String>();
			s.add(v.get(i).getFlag());
			s.add(v.get(i).getcAddress());
			s.add(v.get(i).getGoods().getId());
			s.add(v.get(i).getNum());
			s.add(v.get(i).getDate());
			dtm.addRow(s);
		}
	}
	private void fillTable()
	{
		SearchRecordDao dao = new SearchRecordDao();
		Vector<Goods> g = null;
		try {
			g = dao.findAllGoods();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		
		for(int i= 0;i<g.size();i++)
		{
			Vector<String> s = new Vector<String>();
			s.add(g.get(i).getId());
			s.add(g.get(i).getName());
			s.add(g.get(i).getNum());
			s.add(g.get(i).getPrice());
			s.add(g.get(i).getProductor());
			dtm.addRow(s);
		}
	}
	private void concleActionPerformed()
	{
		new OperatorUI().run();
		this.dispose();
		
	}
	public void run() {
		
		setVisible(true);
}
}
