package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import Dao.AddGoodsDao;
import Model.Goods;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddGoodsView extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddGoodsView frame = new AddGoodsView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddGoodsView() {
		setTitle("\u589E\u52A0\u8D27\u7269");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 232, 273);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 196, 178);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u540D\u79F0\uFF1A");
		lblNewLabel.setBounds(10, 27, 54, 15);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(60, 24, 91, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u5355\u4EF7\uFF1A");
		lblNewLabel_1.setBounds(10, 77, 54, 15);
		panel.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(60, 74, 91, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\u6570\u76EE\uFF1A");
		lblNewLabel_2.setBounds(10, 127, 54, 15);
		panel.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(60, 124, 91, 21);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("\u4FDD\u5B58");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				insertActionPerformed();
			}
		});
		btnNewButton.setBounds(10, 198, 93, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u5173\u95ED");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelactionPerformed();
			}
		});
		btnNewButton_1.setBounds(113, 198, 93, 23);
		contentPane.add(btnNewButton_1);
	}
			public void run() {
					setVisible(true);
			}
			private void insertActionPerformed()
			{
				Goods g=new Goods();
				if(textField.getText().equals("")||textField_1.getText().equals("")||textField_2.getText().equals(""))
					JOptionPane.showMessageDialog(null, "��������Ϣ.");
				else
				{
				g.setName(textField.getText());
				g.setPrice(textField_1.getText());
				g.setNum(textField_2.getText());
				AddGoodsDao adddao = new AddGoodsDao();
				try {
					adddao.insert(g);
					JOptionPane.showMessageDialog(null, "���ӳɹ�");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			}
			private void  cancelactionPerformed()
			{
				new OperatorUI().run();
				this.dispose();
			}
}
