package View;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;



import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class OperatorUI extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OperatorUI frame = new OperatorUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OperatorUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 597, 87);
		contentPane.add(panel);
		panel.setLayout(null);

		JButton btnNewButton = new JButton("\u5165\u5E93\u64CD\u4F5C");
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				entryRecordActionPerformed(e);
			}
		});
		btnNewButton.setBounds(123, 10, 93, 67);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u51FA\u5E93\u64CD\u4F5C");
		btnNewButton_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				outRecordActionPerformed(e);
			}
		});
		btnNewButton_1.setBounds(226, 10, 93, 67);
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton(
				"\u67E5\u770B\u8D27\u7269\u4FE1\u606F");
		btnNewButton_2.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchActionPerformed(e);
			}
		});
		btnNewButton_2.setBounds(329, 10, 128, 67);
		panel.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("\u7EDF\u8BA1\u8D26\u5355");
		btnNewButton_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				countActionPerformed(e);
			}
		});
		btnNewButton_3.setBounds(467, 10, 105, 67);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\u589E\u52A0\u8D27\u7269");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addActionPerformed();
			}
		});
		btnNewButton_4.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton_4.setBounds(10, 10, 103, 67);
		panel.add(btnNewButton_4);
	}

	public void entryRecordActionPerformed(ActionEvent e) {
		new EntryRecordView().run();
		this.dispose();
	}
	

	public void outRecordActionPerformed(ActionEvent e) {
		new OutRecordView().run();
		this.dispose();
	}

	public void searchActionPerformed(ActionEvent e) {
		new SearchRecordView().run();
		this.dispose();
	}

	public void countActionPerformed(ActionEvent e) {
		new CountRecordView().run();
		this.dispose();
	}
	public void addActionPerformed() {
		new AddGoodsView().run();
		this.dispose();
	}

	public void run() {
		setVisible(true);
	}
}
