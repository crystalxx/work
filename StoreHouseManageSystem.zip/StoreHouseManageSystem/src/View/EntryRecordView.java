package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

import Dao.EntryRecordDao;
import Model.EntryRecord;
import Model.Goods;
import Model.Operator;
import Model.Record;
import Util.StringUtil;

import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.DateFormat;
import java.util.Date;
import java.util.Vector;
import java.awt.Font;

public class EntryRecordView extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EntryRecordView frame = new EntryRecordView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EntryRecordView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 573, 447);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 536, 388);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 117, 516, 235);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"\u8D27\u7269\u7F16\u53F7", "\u6570\u91CF", "\u4ED3\u5E93"
			}
		));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("\u5165\u5E93\u5355");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		lblNewLabel.setBounds(234, 10, 54, 15);
		panel.add(lblNewLabel);
		
		JLabel label = new JLabel("\u4F9B\u5E94\u5546:");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(10, 49, 54, 15);
		panel.add(label);
		
		JLabel label_1 = new JLabel("\u65E5\u671F\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_1.setBounds(260, 49, 54, 15);
		panel.add(label_1);
		
		JButton btnNewButton = new JButton("\u4FDD\u5B58");
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sureAction();
			}
		});
		btnNewButton.setBounds(210, 362, 93, 23);
		panel.add(btnNewButton);
		
		textField = new JTextField();
		textField.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		textField.setBounds(63, 45, 86, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		textField_1.setEditable(false);
		textField_1.setBounds(324, 46, 145, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JButton button = new JButton("\u6DFB\u52A0\u7269\u54C1");
		button.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				dtm.addRow(new String[]{"","","",""});
			}
		});
		button.setBounds(10, 84, 93, 23);
		panel.add(button);
		Date date = new Date();
        DateFormat df = DateFormat.getDateTimeInstance();
        textField_1.setText(df.format(date));
	}
	
	private void sureAction()
	{
		String s = StringUtil.deleteBlank(textField.getText());
		if(!s.equals(""))
		{
			DefaultTableModel dtm = (DefaultTableModel) table.getModel();
			int row = dtm.getRowCount();
			Vector <Record> re =new Vector<Record>();
			Date date = new Date();
	        DateFormat df = DateFormat.getDateTimeInstance();
	        EntryRecordDao erDao = new EntryRecordDao();
	        int max = 0;
	        try {
				 max = (Integer.parseInt(erDao.findMax()))+1;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        
			for(int i = 0;i<row;i++)
			{
					Record r= new EntryRecord();
					r.setGoods(new Goods());
					
						if(erDao.select(dtm.getValueAt(i, 0).toString())!=1)
						{
							
							JOptionPane.showMessageDialog(null, "û�е�"+(i+1)+"�л���ļ�¼��");	
							return;
						}
						if(erDao.selectStoreHouse(dtm.getValueAt(i, 2).toString())!=1)
						{
							JOptionPane.showMessageDialog(null, "û�е�"+(i+1)+"�еĸòֿ��¼��");	
							return;
						}
					r.getGoods().setId(dtm.getValueAt(i, 0).toString());
					r.setNum(dtm.getValueAt(i, 1).toString());
					r.setcAddress(dtm.getValueAt(i, 2).toString());
					r.setFlag(String.valueOf(max));
					r.setDate(df.format(date));
					r.setPro(textField.getText());
					re.add(r);
			}
			try {
				erDao.insert(re);
				erDao.update(re);
				JOptionPane.showMessageDialog(null, "���ɹ���");
				new OperatorUI().run();
				dispose();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "���ݴ洢ʧ��!");
			}
			
		}
		else
			JOptionPane.showMessageDialog(null, "�������ṩ�̣�");
		
	}
	public void run() {
		setVisible(true);		
	}
	
}
