package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Dao.EntryRecordDao;
import Dao.OutRecordDao;
import Model.EntryRecord;
import Model.Goods;
import Model.OutRecord;
import Model.Record;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.DateFormat;
import java.util.Date;
import java.util.Vector;

import javax.swing.JTextField;

import java.awt.Font;

public class OutRecordView extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OutRecordView frame = new OutRecordView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OutRecordView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 535, 451);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 499, 392);
		panel.setLayout(null);
		contentPane.add(panel);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 66, 479, 286);
		panel.add(scrollPane);

		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u7269\u54C1\u7F16\u53F7", "\u6570\u76EE", "\u4ED3\u5E93\u7F16\u53F7"
			}
		));
		scrollPane.setViewportView(table);

		JLabel label = new JLabel("\u51FA\u5E93\u5355");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(234, 10, 54, 15);
		panel.add(label);

		JLabel label_3 = new JLabel("\u65E5\u671F\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_3.setBounds(10, 41, 54, 15);
		panel.add(label_3);

		JButton button = new JButton("\u4FDD\u5B58");
		button.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sureAction();
			}
		});
		button.setBounds(114, 362, 93, 23);
		panel.add(button);

		JButton button_1 = new JButton("\u5173\u95ED");
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				concleActionPerformed();
			}
		});
		button_1.setBounds(268, 362, 93, 23);
		panel.add(button_1);
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0\u7269\u54C1");
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				dtm.addRow(new String[]{"","",""});
			}
		});
		btnNewButton.setBounds(268, 35, 93, 23);
		panel.add(btnNewButton);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		textField_1.setEditable(false);
		textField_1.setBounds(74, 35, 125, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);
		Date date = new Date();
        DateFormat df = DateFormat.getDateTimeInstance();
        textField_1.setText(df.format(date));
	}
	private void sureAction()
	{
		
		DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		int row = dtm.getRowCount();
		Vector<Record> re =new Vector<Record>();
		Date date = new Date();
        DateFormat df = DateFormat.getDateTimeInstance();
        OutRecordDao dao = new OutRecordDao();
        Integer max = 0;
        try {
			 max = Integer.parseInt(dao.findMax())+1;
			 
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i = 0;i<row;i++)
		{
				Record r= new OutRecord();
				if(dao.select(dtm.getValueAt(i, 0).toString())!=1)
				{
					
					JOptionPane.showMessageDialog(null, "û�е�"+(i+1)+"�л���ļ�¼��");	
					return;
				}
				if(dao.selectStoreHouse(dtm.getValueAt(i, 2).toString())!=1)
				{
					JOptionPane.showMessageDialog(null, "û�е�"+(i+1)+"�еĸòֿ��¼��");	
					return;
				}
				if(dao.isEnough(dtm.getValueAt(i, 0).toString(),dtm.getValueAt(i, 1).toString())!=1)
				{
					JOptionPane.showMessageDialog(null, "��"+(i+1)+"�еĻ����治����");	
					return;
				}
				r.setGoods(new Goods());
				r.getGoods().setId(dtm.getValueAt(i, 0).toString());
				r.setNum(dtm.getValueAt(i, 1).toString());
				r.setcAddress(dtm.getValueAt(i, 2).toString());
				r.setFlag(String.valueOf(max));
				r.setDate(df.format(date));
				re.add(r);
		}
		try {
			dao.insert(re);
			dao.update(re);
			JOptionPane.showMessageDialog(null, "����ɹ���");
			new OperatorUI().run();
			dispose();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");
		}
	}
	public void run() {
		setVisible(true);
	}
	private void concleActionPerformed()
	{
		new OperatorUI().run();;
		this.dispose();
		
	}
}
