package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;

import Dao.SearchRecordDao;
import Model.Goods;
import Model.Record;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Vector;

public class CountRecordView extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CountRecordView frame = new CountRecordView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CountRecordView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 617, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u67E5\u8BE2\u6761\u4EF6", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 10, 581, 65);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8BF7\u9009\u62E9\u5165\u5E93\u5355\uFF1A");
		lblNewLabel.setBounds(50, 27, 102, 15);
		panel.add(lblNewLabel);
		
		 comboBox = new JComboBox();
		comboBox.setBounds(190, 24, 116, 21);
		panel.add(comboBox);
		
		JButton btnNewButton = new JButton("\u8BA1\u7B97");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			count();
			}
		});
		btnNewButton.setBounds(354, 23, 93, 23);
		panel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 85, 581, 317);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"\u8D27\u7269\u7F16\u53F7", "\u540D\u79F0", "\u5355\u4EF7", "\u6570\u91CF", "\u5C0F\u8BA1"
			}
		));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_1 = new JLabel("\u603B\u4EF7\uFF1A");
		lblNewLabel_1.setBounds(95, 415, 54, 15);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(159, 412, 134, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\u5173\u95ED");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				concleActionPerformed();
			}
		});
		btnNewButton_1.setBounds(360, 411, 93, 23);
		contentPane.add(btnNewButton_1);
		fillcomboBox();
	}

	private void fillcomboBox()
	{
		SearchRecordDao dao = new SearchRecordDao();
		Vector<String> flag=null;
		try {
			flag = dao.findFlagEntryRecord();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!flag.isEmpty())
		{
			for(int i=0;i<flag.size();i++)
			{
				comboBox.addItem(flag.get(i));
			}
		}
	}
	private void fillTable(String flag)
	{
		SearchRecordDao dao = new SearchRecordDao();
		Vector<Record> reSet = null;
		try {
			reSet = dao.findEntryRecord(flag);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		Double temp=new Double(0.0);
		Double sum =new Double(0.0);
		
		for(int i= 0;i<reSet.size();i++)
		{
			Vector<String> s = new Vector<String>();
			
			Vector<Goods> goods=null;
			try {
				goods = dao.findGoods(reSet.get(i).getGoods().getId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			s.add(goods.get(0).getId());
			s.add(goods.get(0).getName());
			s.add(goods.get(0).getPrice());
			s.add(reSet.get(i).getNum());
			temp= Integer.parseInt(reSet.get(i).getNum())*Double.parseDouble(goods.get(0).getPrice());
			sum = sum+temp;
			s.add(temp.toString());
			dtm.addRow(s);
		}
		textField.setText(sum.toString());
		
	}
	private void count()
	{
		String s = comboBox.getSelectedItem().toString();
		
		fillTable(s);
		
	}
	private void concleActionPerformed()
	{
		new OperatorUI().run();
		this.dispose();
	}
	public void run() {
		
			setVisible(true);
	}
}

