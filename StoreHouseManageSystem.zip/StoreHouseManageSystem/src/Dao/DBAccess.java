package Dao;

import java.sql.Connection;
import java.sql.DriverManager;

public abstract class DBAccess {

	private String dbUrl = "jdbc:mysql://localhost:3306/db";
	private String dbUserName = "root";
	private String dbPassword = "";
	private String jdbcName = "com.mysql.jdbc.Driver";

	public Connection getConnect() throws Exception {
		Class.forName(jdbcName);
		Connection con = DriverManager.getConnection(dbUrl, dbUserName,
				dbPassword);
		return con;
	}

	public void closeConnect(Connection con) throws Exception {
		if (con != null) {
			con.close();
		}
	}
	

}
