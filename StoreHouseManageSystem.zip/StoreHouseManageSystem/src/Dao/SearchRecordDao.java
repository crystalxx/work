package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;




import Model.EntryRecord;
import Model.Goods;
import Model.Record;

public class SearchRecordDao extends DBAccess{
	public Vector<Record> findEntryRecord(String s) throws Exception
	{
		Vector<Record> re = new Vector<Record>();
		String sql ="select *from entryrecordtable where flag=?";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			
				pstmt.setString(1, s);
			ResultSet r = pstmt.executeQuery();
			Record record ;
			while(r.next())
			{
				record = new EntryRecord();
				record.setcAddress(r.getString("c_id"));
				record.setGoods(new Goods());
				record.getGoods().setId(r.getString("g_id"));
				record.setDate(r.getString("time"));
				record.setNum(r.getString("num"));
				record.setFlag(r.getString("flag"));
				re.add(record);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return re;
	}
	public Vector<Record> findOutRecord(String s) throws Exception
	{
		Vector<Record> re = new Vector<Record>();
		String sql ="select *from outrecordtable where flag=?";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			
				pstmt.setString(1, s);
			ResultSet r = pstmt.executeQuery();
			Record record ;
			while(r.next())
			{
				record = new EntryRecord();
				record.setcAddress(r.getString("c_id"));
				record.setGoods(new Goods());
				record.getGoods().setId(r.getString("g_id"));
				record.setDate(r.getString("time"));
				record.setNum(r.getString("num"));
				record.setFlag(r.getString("flag"));
				re.add(record);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return re;
	}
	public Vector<Goods> findGoods(String g_id) throws Exception
	{
		Vector<Goods> re = new Vector<Goods>();
		String sql ="select *from goodstable where g_id=?";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			
				pstmt.setString(1, g_id);
			ResultSet r = pstmt.executeQuery();
			Goods g ;
			while(r.next())
			{
				g = new Goods();
				g.setId(r.getString("g_id"));
				g.setName(r.getString("g_name"));
				g.setNum(r.getString("g_num"));
				g.setPrice(r.getString("g_price"));
				g.setNum(r.getString("g_productor"));
				re.add(g);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return re;
	}
	public Vector<Goods> findAllGoods() throws Exception
	{
		Vector<Goods> re = new Vector<Goods>();
		String sql ="select *from goodstable";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			
			ResultSet r = pstmt.executeQuery();
			Goods g ;
			while(r.next())
			{
				g = new Goods();
				g.setId(r.getString("g_id"));
				g.setName(r.getString("g_name"));
				g.setNum(r.getString("g_num"));
				g.setPrice(r.getString("g_price"));
				g.setProductor(r.getString("g_productor"));
				re.add(g);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return re;
	}
	public Vector<String> findFlagEntryRecord() throws Exception
	{
		Vector<String> re = new Vector<String>();
		String sql ="select distinct flag from entryrecordtable";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			ResultSet r = pstmt.executeQuery();
			String g ;
			while(r.next())
			{
				re.add(r.getString("flag"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return re;
	}
	public Vector<String> findFlagOutRecord() throws Exception
	{
		Vector<String> re = new Vector<String>();
		String sql ="select distinct flag from outrecordtable";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			ResultSet r = pstmt.executeQuery();
			String g ;
			while(r.next())
			{
				re.add(r.getString("flag"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return re;
	}
}
