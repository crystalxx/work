package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

import Model.Goods;
import Model.Record;

public class AddGoodsDao extends DBAccess {

	public void insert(Goods re) throws Exception
	{
		String sql ="insert into goodstable (g_name,g_num,g_price,g_productor) values (?,?,?,?)";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			
				pstmt.setString(1, re.getName());
				pstmt.setString(2, re.getNum());
				pstmt.setString(3, re.getPrice());
				pstmt.setString(4, re.getProductor());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
