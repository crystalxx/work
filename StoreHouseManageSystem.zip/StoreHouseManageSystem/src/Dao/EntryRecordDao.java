package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import Model.Goods;
import Model.Record;


public class EntryRecordDao extends DBAccess{
	public void insert(Vector<Record> re) throws Exception
	{
		String sql ="insert into entryrecordtable (c_id,g_id,time,flag,num,pro) values (?,?,?,?,?,?)";
		PreparedStatement pstmt = null;
			Connection con = getConnect();
			pstmt = con.prepareStatement(sql);
			
		try {
			for(int i =0;i<re.size();i++)
			{
				pstmt.setString(1, re.get(i).getcAddress());
				pstmt.setString(2, re.get(i).getGoods().getId());
				pstmt.setString(3, re.get(i).getDate());
				pstmt.setString(4, re.get(i).getFlag());
				pstmt.setString(5, re.get(i).getNum());
				pstmt.setString(6, re.get(i).getPro());
			pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Exception();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void update(Vector<Record> re) throws Exception
	{
		String sql = "update goodstable set g_num=g_num+? where g_id=?";
		PreparedStatement pstmt = null;
		Connection con = getConnect();
		pstmt = con.prepareStatement(sql);
		try {
			for(int i =0;i<re.size();i++)
			{
				pstmt.setString(1, re.get(i).getNum());
				pstmt.setString(2, re.get(i).getGoods().getId());
			pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public String findMax() throws Exception
	{
		String sql = "select max(flag) from entryrecordtable";
		PreparedStatement pstmt = null;
		Connection con = getConnect();
		pstmt = con.prepareStatement(sql);
		String s =null;
		try {
			ResultSet re = pstmt.executeQuery();
			while (re.next()) {
				s =re.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				closeConnect(con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return s;
	}
	public int select(String s)
	{
		String sql ="select *from goodstable where g_id=?";
		PreparedStatement pstmt = null;
		int flag = 0;
			Connection con=null;
			try {
				con = getConnect();
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			try {
				pstmt = con.prepareStatement(sql);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				pstmt.setString(1, s);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		try {
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				flag = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			flag  = 0;
		} finally {
			try {
				pstmt.close();
				try {
					closeConnect(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}
	public int selectStoreHouse(String s)
	{
		String sql ="select *from storehousetable where c_id=?";
		PreparedStatement pstmt = null;
		int flag = 0;
			Connection con=null;
			try {
				con = getConnect();
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			try {
				
				pstmt = con.prepareStatement(sql);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				pstmt.setString(1, s);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		try {
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				flag = 1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			flag = 0;
		} finally {
			try {
				pstmt.close();
				try {
					closeConnect(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return flag;
	}


}

