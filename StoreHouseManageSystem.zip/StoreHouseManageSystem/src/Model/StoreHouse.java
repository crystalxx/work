package Model;

import java.util.Vector;

public class StoreHouse {
	private String id;//�ֿ���
	private String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private  Vector<Record> record;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Vector<Record> getRecord() {
		return record;
	}
	public void setRecord(Vector<Record> record) {
		this.record = record;
	}

	
}
