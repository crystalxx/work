package Model;

public class OutRecord extends Record {


}
