package Model;

public class EntryRecord extends Record {

}
